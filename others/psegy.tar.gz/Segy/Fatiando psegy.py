# -*- coding: utf-8 -*-
# <nbformat>3.0</nbformat>

# <codecell>

%cd fatiando
%cd seismic
from psegy import Segy
import numpy as np

with Segy("cloudpspin635.segy") as sgy:
    ntrac = sgy.numbertraces
    nsamples = sgy.samplestrace
    
    print ntrac, nsamples
    
    trace = np.zeros([ntrac, nsamples])
    
    for i in range(ntrac):
        trace[i] = sgy.traces(i).samples
        
    atrace = sgy.traces(i)

# <codecell>

import matplotlib.pylab as pylab
pylab.rcParams['figure.figsize'] = 13, 13  # that's default image size for this interactive session
imshow(trace.transpose(), interpolation='bicubic', cmap=pylab.cm.gray, vmin=-25, vmax=25, aspect=0.5, origin='upper', extent=[0,ntrac*10,0,nsamples*sgy.samplerate*0.001])
pylab.rcParams['figure.figsize'] = 4, 4  # that's default image size for this interactive session

# <codecell>

#-------------- Testing copying writing a trace ------------------------

# <codecell>

import struct
atracepacked = atrace._pack()
print len(atracepacked) 
print len(atrace.samples)*4 + 240

# <codecell>

from psegy import Trace

# <codecell>

btrace = Trace(atracepacked, 5)

# <codecell>

error = numpy.zeros(len(atrace.samples))
for i in range(len(atrace.samples)):
    error[i] = (atrace.samples[i] - btrace.samples[i])**2

# <codecell>

plot(error)
print max(error)

# <codecell>

# ------------------------ Testing copying entire file ------------------------
# read marmousi traces, storing it 
# write a segy using those traces and defautl ebcdic/binaryheader
# read the newly created file back

# <codecell>

%cd fatiando
%cd seismic

from psegy import Segy, EBCDIC, Trace, SegyTH, SegyBH
import numpy as np

%cd gngdata
%cd Marmousi

traces = []
ntrac = nsamples = 0

with Segy("marmousi_001.segy") as sgy:
    ntrac = sgy.numbertraces
    nsamples = sgy.samplestrace
    
    print ntrac, nsamples
    
    for i in range(ntrac):
        traces.append(sgy.traces(i))
    
segy = Segy("marmousi_001cp.sgy", traces, EBCDIC, SegyBH())
segy.write()

with Segy("marmousi_001cp.sgy") as sgy:
    ntrac = sgy.numbertraces
    nsamples = sgy.samplestrace
    
    print ntrac, nsamples
    
    trace = np.zeros([ntrac, nsamples])
    
    for i in range(ntrac):
        trace[i] = sgy.traces(i).samples

# <codecell>

shape(trace)

# <codecell>

import matplotlib.pylab as pylab
pylab.rcParams['figure.figsize'] = 12, 12  # that's default image size for this interactive session
imshow(trace.transpose(), aspect=0.2, origin='upper', cmap=pylab.cm.gray_r, extent=[0,ntrac*10,nsamples*sgy.samplerate*0.001, 0])
pylab.rcParams['figure.figsize'] = 4, 4  # that's default image size for this interactive session

# <codecell>

# ------open cloudspin 635 read all traces apply simple moving average filter
# ------write it back and plot the result

# <codecell>

%cd fatiando
%cd seismic
from psegy import Segy, EBCDIC, SegyBH
import numpy as np
%cd gngdata
%cd OtherSegy

# Read the segy file and get the traces
with Segy("cloudpspin635.segy") as sgy:
    ntrac = sgy.numbertraces
    nsamples = sgy.samplestrace    
    cloudp_traces = []
    cloud_image_trace = np.zeros([ntrac, nsamples])
    
    for i in range(ntrac):
        cloud_image_trace[i] = sgy.traces(i).samples
        cloudp_traces.append(sgy.traces(i))
        
# apply moving average over trace samples size 5 samples
for trace in cloudp_traces:
    ns = trace.numbersamples()
    for i in range(ns):
        s2 = s1 = s_2 = s_1 = trace.samples[i]
        if i-2 > -1 : 
            s_2 = trace.samples[i-2]
        if i-1 > -1 : 
            s_1 = trace.samples[i-1]
        if i+2 < ns : 
            s2 = trace.samples[i+2]
        if i+1 < ns:            
            s1 = trace.samples[i+1]                        
        trace.samples[i] = (s1+s2+s_1+s_2+trace.samples[i])/5.0
        
# write back the new traces as a new file
segy = Segy("cloudpspin635_smooth.segy", cloudp_traces, EBCDIC, SegyBH())
segy.write()

# Read the newly created file for plotting 
with Segy("cloudpspin635_smooth.segy") as sgy:
    ntrac = sgy.numbertraces
    nsamples = sgy.samplestrace   
    cloud_smooth_image_trace = np.zeros([ntrac, nsamples])
    
    for i in range(ntrac):
        cloud_smooth_image_trace[i] = sgy.traces(i).samples

import matplotlib.pylab as pylab
pylab.rcParams['figure.figsize'] = 13, 13  # that's default image size for this interactive session

fig = figure()
ax = fig.add_subplot(1,2,1)
ax.imshow(cloud_image_trace.transpose(), interpolation='bicubic', cmap=pylab.cm.gray, vmin=-25, vmax=25, aspect=0.5, origin='upper', extent=[0,ntrac*10,0,nsamples*sgy.samplerate*0.001])
ax.set_title('Cloudpsin',fontsize=10)

ax = fig.add_subplot(1,2,2)
ax.imshow(cloud_smooth_image_trace.transpose(), interpolation='bicubic', cmap=pylab.cm.gray, vmin=-25, vmax=25, aspect=0.5, origin='upper', extent=[0,ntrac*10,0,nsamples*sgy.samplerate*0.001])
ax.set_title('Cloudpsin moving average',fontsize=10)

pylab.rcParams['figure.figsize'] = 4, 4  # that's default image size for this interactive session

# <codecell>


